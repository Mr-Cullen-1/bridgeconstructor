# Evidence and limits

Research synthesis: 2026-10-26. Links support the findings below; design recommendations are an application of that evidence, not effect sizes measured for this skill. Documentation and repositories are moving targets. Check current host behavior before changing adapters.

## What problem this addresses

People often discover what they meant only after seeing a concrete interface. A single polished proposal encourages incremental edits around the first idea. Isolated mockups omit the page constraints that later cause rework. State and content variations appear late, and verbal decisions lose their references during handoff.

Our motivating case involved comparing three card compositions and locked/open/completed states. Seeing the card within its page exposed height constraints; later modal and fullscreen issues showed why isolated component review alone was insufficient. This is a case observation, not a controlled evaluation. The distributable example uses synthetic content and no assets from that project.

## Research findings

| Source and evidence type | Finding | Application and limit |
| --- | --- | --- |
| [Dow et al., 2010, parallel prototyping](https://doi.org/10.1145/1879831.1879836), controlled study of 33 ad designers | Parallel creation and critique improved several design outcomes and diversity compared with serial iteration. | Compare alternatives before committing. The task involved web advertisements, not production application workflows; no universal productivity percentage follows. |
| [Tohidi et al., CHI 2006](https://ronbaecker.com/wp-content/uploads/2023/06/getting_the_right_design_and_the_design_right.pdf), study of 48 participants | Showing three functionally equivalent designs reduced inflated ratings and encouraged criticism relative to one. More alternatives did not reliably elicit better improvement suggestions. | Let reviewers compare and reject, while the agent remains responsible for proposing fixes. Preference is not a substitute for task-based usability testing. |
| [Scheibehenne et al., 2010](https://scheibehenne.de/ScheibehenneGreifenederTodd2010.pdf), meta-analysis of 50 experiments | The average choice-overload effect was near zero, with substantial variation. | Do not assert a universal optimal number. Three alternatives is a manageable starting budget, adjusted to the decision. |
| [Design Council, Double Diamond](https://www.designcouncil.org.uk/resources/the-double-diamond/), practice framework | Understand the problem, explore answers, then test and converge. | Preserve both divergence and convergence; do not create endless alternative batches without addressing the missed constraint. |
| [NN/g design critiques](https://www.nngroup.com/articles/design-critiques/), practitioner guidance | Clear scope, shared objectives and a constructive discussion improve critique. | Ask about the user's task and observable friction; record decisions and reasons instead of collecting unstructured aesthetic votes. |
| [Doshi & Hauser, Science Advances 2024](https://doi.org/10.1126/sciadv.adn5290), creative writing experiment | AI assistance improved individual story evaluations while making outputs more similar across writers. | A caution to assess real diversity among generated candidates. This is not direct evidence about UI design; do not transfer its effect sizes. |
| [SkillsBench, 2026 preprint](https://arxiv.org/html/2602.12670v1), agent benchmark | Skill effects vary by task and harness; focused procedural instructions can help, while added context can also hurt. | Validate behavior across hosts instead of just validating YAML. Terminal benchmark results do not establish usability or design quality. |

## Existing approaches and the intended contribution

**Storybook** already provides [state stories](https://storybook.js.org/docs/writing-stories/index), [page composition](https://storybook.js.org/docs/writing-stories/build-pages-with-storybook), and [viewport controls](https://storybook.js.org/docs/essentials/viewport). Reuse it rather than build another component catalog. This skill adds a conversational decision protocol, fair alternative comparison and a recorded choice leading into implementation.

**[Superpowers Visual Companion](https://github.com/obra/superpowers/blob/main/skills/brainstorming/visual-companion.md)** already supports browser-based alternatives. This skill builds on the general idea of visual dialogue, with explicit state/context coverage and reuse of the chosen component. It does not claim invention of visual brainstorming or copy that companion's implementation.

**[Anthropic frontend-design](https://github.com/anthropics/skills/blob/main/skills/frontend-design/SKILL.md)** guides visual direction and execution. UI Variants can coexist with it: the former can produce candidates, while this skill organizes comparison and convergence. Follow an existing design system unless the task calls for changing it.

## Portability

The [Agent Skills specification](https://agentskills.io/specification) provides a shared SKILL.md format. [Codex](https://learn.chatgpt.com/docs/build-skills), [Claude Code](https://code.claude.com/docs/en/skills), and [Gemini CLI](https://geminicli.com/docs/cli/skills/) expose skills through different discovery, tool and permission mechanisms. Keep standard frontmatter in the core and provider metadata separate. Never assume that matching format means identical execution or automatic activation.

## Evaluating the 90% aspiration

“Eliminates 90% of design problems” is not an established result. This workflow plausibly reduces ambiguous requests, late state/layout discoveries and loss of decisions. It does not automate stakeholder authority, business priority conflicts, research recruitment or validation with real end users.

Measure time to a sufficiently specific choice, clarification cycles, reopened decisions, post-integration rework and total effort including preview creation. Compare similar tasks with and without the skill; account for familiarity, task difficulty, model/harness version and ordering effects. Report pilot observations separately from causal or broadly generalizable claims. See [evaluation protocol](evaluation.md).
