# Preview adapters

Choose by what the project already has. The protocol is portable; rendering adapters are intentionally project-specific.

## Existing Storybook

Import the real components. Reuse existing stories, args, providers and network mocks. Add meaningful state stories and a comparison composition that renders candidates with the same fixture values. Add page-context stories where neighboring content, routing or overlays matter. Use viewport controls for both width and height; provide direct story/args links. Respect the project's installed Storybook version instead of copying APIs from a different version.

## Existing application without Storybook

Use a development entrypoint or fixture route in the project's own stack. Reuse components, tokens, fonts, providers and relevant page layout. Keep mock responses local and deterministic; block or intercept submission/navigation effects. A visual mock and the live component should not drift into unrelated copies.

Provide compare, states and page-context views. Give the current revision and candidates stable labels. Store selection in the URL so a link restores the same view. A suggested local interface is `revision`, `variant`, `state`, `case`, `lang`, `width`, `height`, and `view`; use the host's established conventions when present. These are preview settings, not new public product API fields.

For contextual viewports, an iframe isolates media queries and fixed positioning better than a narrow div. If an iframe is inappropriate, use an equivalent full-window route at actual viewport size. Review controls must not consume height inside the measured product viewport; the full-window route should show only the product scene. Do not claim that a CSS-transformed screenshot tests responsiveness. Ensure focus, dialogs and router navigation work within the chosen frame boundary.

Make the entrypoint development-only using the framework's established mechanism. Check the production build/route output for accidental gallery exposure. A hidden navigation link alone is not exclusion. Non-selected variants should not remain product branches solely to serve a comparison.

## No application or preview infrastructure

Copy `assets/gallery.html` into a task-owned local preview directory. It works as a self-contained file, without a package manager or external assets. Its included session card is a synthetic example to replace, not a mandated aesthetic. Adapt the candidates, states, fixture data and page composition to the task. The shared renderer drives all three views; keep that relationship when adapting it.

The template has URL settings, stable A/B/C labels, state and language controls, actual iframe width/height, content cases and a native-size view. Its play action changes only local state. It has no backend, comments database or click-to-approve behavior. The copy-link button copies a reproducible URL; it does not claim localhost or file URLs are accessible to teammates.

If using a development server, use the project's existing process and port. Check it is alive before sharing; restart only the task's process if necessary. Prefer loopback binding for a local preview. Remote environments may require port forwarding or an approved preview surface: provide the reachable address, not an assumed localhost link. Publishing externally is a separate authorized action.

## Reduced capabilities

If the agent cannot run a browser, still provide the runnable local artifact and accurately mark it unverified. Static image alternatives must use the same content, size and labels; state what interactions are absent. A broken server is not a reason to claim screenshots were reviewed. Resolve missing capability without silently switching the deliverable to a hosted product or adding a paid service.

## Comparison quality

- Keep the task, data and fidelity comparable; distinguish alternative layouts from state transitions.
- Show only meaningful state combinations. Disabled and loading are different only if that distinction matters to the product.
- Default to one common state across candidates, then allow states view. Do not launch dozens of frames for every locale/size combination.
- Preserve natural text wrapping and overflow. Include a short-height scenario when vertical fit matters.
- Record illustrative placeholders as assumptions, especially in a page-context mock.
- Evaluate real runtime dimensions after fonts/images load; screenshots supplement measurements and human inspection.

Primary references: [Storybook stories](https://storybook.js.org/docs/writing-stories/index), [page composition](https://storybook.js.org/docs/writing-stories/build-pages-with-storybook), [network mocking](https://storybook.js.org/docs/writing-stories/mocking-data-and-modules/mocking-network-requests), [viewport](https://storybook.js.org/docs/essentials/viewport).
