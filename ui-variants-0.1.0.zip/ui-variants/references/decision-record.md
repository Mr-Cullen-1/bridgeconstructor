# Decision record

Use the project's existing decision log if available. Otherwise keep a small task-owned Markdown record near its preview. One record per decision is sufficient. Update accepted decisions explicitly; preserve earlier revisions in version control or the record.

```markdown
# Decision: [component or task]

- Task / audience:
- Decision being made:
- Fixed constraints:
- Preview revision and reproducible link:
- Candidate IDs and meaningful differences:
- Relevant states, content cases, locales and viewport dimensions:
- Selected candidate / accepted combination:
- Explicitly rejected parts:
- User's stated reason (or "not supplied"):
- Outstanding assumptions:
- Source component/story references:
- Validation performed and limitations:
- Integration status / follow-up:
```

Example feedback: “Use B, with A's heading; keep the compact footer.” Record B's composition, A's heading and the compact footer as separate accepted constraints. Do not interpret that as choosing every property of A. If another stakeholder disagrees, preserve both comments and ask who owns that decision rather than counting votes or treating the last click as approval.

Share the record and reproducible scenario with the implementing agent. Do not export secrets, real account data or private assets in a public example. Local paths are references for collaborators with repository access, not public URLs.
