# Behavioral evaluation

Validate naming/frontmatter/links first, then observable behavior. Correct wording alone does not prove a useful skill. The repository's `evals/cases.json` supplies synthetic requests and acceptance criteria; keep criteria hidden from the model during forward testing.

## Evaluation layers

1. **Conversation:** ask the agent to handle a realistic request using only the brief and skill. Inspect whether it offers the visual option, avoids unnecessary interviews, respects accepted choices and reports limitations honestly.
2. **Artifact:** in an isolated task directory, ask for the requested comparison. Open the generated artifact, follow its links and exercise applicable states. Confirm candidate differences, matching content, stable IDs, real page context and no live side effects.
3. **Integration:** select a candidate or combination. Verify the implemented component matches that choice, other accepted constraints remain intact, and preview controls do not enter product output.
4. **Human pilot:** compare equivalent tasks with/without the skill. Do not call a scripted walkthrough human usability research.

Use only authorized agent runtimes and isolated fixtures. Do not spawn additional agents or spend money merely because the skill is installed. An explicitly requested cross-agent evaluation authorizes its stated test scope; broader external actions still require their own authorization.

## Pass criteria

- A genuine UI choice includes a translated Show all variants answer, even if the host's question widget has a small option limit.
- An explicit request for variants proceeds to the gallery without asking whether to make one.
- Exact fixes, approved references and backend questions do not produce a new design interview.
- Candidates differ in the discussed dimension, use common data, and cover relevant states/context.
- The selected combination is traceable into implementation and does not silently reset previous constraints.
- Artifact links are functional or explicitly marked unavailable; static fallbacks and untested clients are labeled accurately.
- No inference of approval from clicks, no unrequested production writes, no false claim of a verified browser or completed backend.

For a host with no browser tooling, evaluate the capability fallback, not a fictitious successful rendering. Record the model, CLI version, execution mode, fixture, prompt, response, duration and limitations. Distinguish format compatibility, explicit skill use, implicit discovery and end-to-end implementation: a pass at one layer does not establish the others.

## Pilot worksheet

Use at least six representative paired tasks as an exploratory pilot, with different but comparable briefs to reduce learning effects. Alternate condition order. Include a small change, stateful component and contextual page layout. Keep model/tool versions and project constraints stable. Record:

| Task | Condition | Time to choice | Clarification cycles | Reopened decisions | Integration rework | Total effort | Constraints / reviewer |
| --- | --- | --- | --- | --- | --- | --- | --- |

Count a clarification cycle as one unresolved design question followed by its answer. Count a reopened decision only when a previously accepted choice changes because of missed information. Track unrelated scope changes separately. Total effort includes generation, human review, preview setup, tests and integration. Report raw measurements and medians with sample size; do not infer a universal improvement percentage from a small pilot.
