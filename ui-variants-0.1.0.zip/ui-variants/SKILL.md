---
name: ui-variants
description: Help people choose UI designs through live side-by-side alternatives, meaningful states, and real page context. Use when exploring or comparing component, layout, visual hierarchy, or interaction directions, or when the user asks to see all variants. Add a Show all variants choice to UI design-choice questions. Do not turn exact fixes, approved designs, or backend decisions into a design interview.
metadata:
  version: "0.1.0"
---

# UI Variants

Make a design decision visible before asking someone to commit to it. Deliver a working comparison and a traceable choice that can become the actual implementation.

## Start from the current decision

Inspect the relevant interface, components, project rules, design system, assets, and previously accepted decisions. Identify the user task and what is still undecided. Reuse information already available; do not interview the user about discoverable facts.

Scale the work to the decision. A precise bug fix, typo, exact reference implementation, or already approved direction normally needs direct work, not invented alternatives. If a real ambiguity remains, ask only about that ambiguity. This skill complements UX and frontend skills; it does not repeat their discovery or replace the project's design language.

## Offer a visual choice

Whenever asking the user to choose between visual or interactive UI solutions, include **Show all variants** (Russian: **Показать все варианты**), translated into the user's language. If previews already exist, include their working link immediately. This is an extra answer, not a replacement for the actual alternatives.

- Explain the decision and each alternative's practical benefit/tradeoff in plain language.
- Offer a recommendation tied to the user task; do not give it more space, polish, or better sample data than the alternatives.
- If the question tool cannot fit all answers plus the preview choice, use a numbered chat question containing all of them. Do not silently omit alternatives or the preview choice.
- Do not add this choice to factual, backend, scheduling, or permission questions that cannot usefully be answered visually.
- Do not ask permission again when the user already requested variants. If the user selects Show all variants, build the comparison within the authorized scope, then wait for their design choice before dependent product implementation. Continue independent work where useful.
- Respect the host's execution mode. A planning-only mode that forbids files also forbids implementing the gallery; plan that next step and explain the limitation without claiming previews exist.

“All” means every proposed alternative for the current decision, not every conceivable design or every combination of state × size × language.

## Build a fair comparison

Start with three meaningfully different alternatives when useful; use fewer for a narrow binary decision and more when explicitly requested. Three is a practical default, not a scientific optimum. Include the current design as a labeled baseline when it helps assess a change.

Vary the dimension under discussion: composition, information hierarchy, density, interaction, or aesthetics. Different colors alone are meaningful for a color decision, not for a navigation decision. Keep the brief's constraints true in every candidate. Reuse real copy/assets where authorized and deterministic representative data. Do not introduce business rules to make a candidate look better.

Provide these views at the fidelity needed to answer the question:

1. **Compare:** alternatives side by side, with stable IDs, concise names, equal rendering dimensions and comparable fidelity.
2. **States:** the actual applicable states of each alternative, with working local interactions where they affect the choice. Examples include locked/open/completed or loading/empty/error/success; derive states from the product instead of applying a universal checklist.
3. **In context:** the component in its real page surroundings, or a clearly labeled representative page when the application does not exist yet. Include neighboring content, header, constraints and scrolling that could change the decision.

Expose state, relevant data cases, language, width **and height** as needed. Compare candidates under the same settings. Use actual viewport/iframe dimensions for responsive inspection; scaled thumbnails are only an overview. Provide a full-size view. Keep all proposed candidates reachable without rendering the entire combinatorial matrix at once.

Use existing components and local mock data. Gallery actions must not submit real records or invoke external side effects. Keep experimental controls outside product flows. Do not promise a complete backend or full end-to-end flow when only key local states are implemented.

Read [preview adapters](references/preview-adapters.md) when building a gallery. Reuse an existing Storybook first, otherwise the project's development environment; use the [standalone gallery](assets/gallery.html) only when no suitable host exists. Do not impose a framework or a new server on a small task.

## Review and converge

Before sharing, check that the URL works and inspect the actual rendered comparison. Report exactly what is interactive, simulated, or unverified. If browser execution is unavailable, provide a runnable artifact or labeled static images and explain the limitation. Never present fabricated screenshots or a text description as a working preview.

Ask for a choice by stable ID and welcome combinations or rejection of all candidates. The user's message is the decision; browsing or clicking is not approval. For “B with A's heading,” preserve B's other accepted properties. If the combination conflicts, explain the specific conflict and offer the smallest useful comparison.

For “none of these,” identify the missed constraint before making another batch. Preserve IDs and revision history; a revised candidate can be `B / revision 2`, while a substantially new direction gets a new ID. Do not overwrite the evidence supporting a prior choice without a versioned record.

Record the decision using the project's existing convention or the [decision record](references/decision-record.md). Capture accepted/rejected parts, rationale when supplied, outstanding assumptions, preview revision and source references—not a transcript. Never invent a user's reason.

Implement the selected component from the same source used in preview where feasible. Check the integrated page, not only the gallery. Keep unselected experiments in development-only artifacts; exclude their code and controls from product entrypoints/builds. Preserve reproducible fixtures and the choice record for later handoff.

Stop exploring once the decision is sufficient to implement. Design agreement does not itself authorize deployment or other external actions.

## Validate proportionately

Check relevant state transitions, meaningful content extremes, keyboard/focus behavior, and selected viewport constraints. Follow project-specific mobile permissions and testing rules. Technical checks and stakeholder preference are not end-user usability research.

Read [behavioral evaluation](references/evaluation.md) when evaluating this skill, and [research and limits](references/research.md) when explaining its evidence or adapting its method. Neither reference is required for an ordinary UI change. Measure actual rework and decision time before claiming productivity gains.
