import assert from 'node:assert/strict';
import { mkdir, writeFile } from 'node:fs/promises';
import { resolve } from 'node:path';
import { pathToFileURL } from 'node:url';
import process from 'node:process';

const { chromium } = await import(process.env.PLAYWRIGHT_MODULE ? pathToFileURL(resolve(process.env.PLAYWRIGHT_MODULE)).href : 'playwright');
const url = pathToFileURL(resolve('skills/ui-variants/assets/gallery.html'));
const evidence = resolve('.evidence/gallery');
await mkdir(evidence, { recursive: true });
const browser = await chromium.launch();
const errors = [], requests = [], results = [];
const context = await browser.newContext({ viewport: { width: 1440, height: 1000 } });
context.on('page', page => page.on('pageerror', error => errors.push(error.message)));
await context.route(/^https?:/, route => { requests.push(route.request().url()); return route.abort(); });
const page = await context.newPage();
const visit = async settings => {
  const target = new URL(url); target.search = new URLSearchParams(settings);
  await page.goto(target.href);
  await page.locator('iframe').first().waitFor();
};
try {
  for (const lang of ['en', 'ru']) for (const view of ['compare', 'states', 'context']) for (const [width,height] of [[320,480],[840,360]]) {
    await visit({lang,view,width,height,case:'long'});
    const expected = view === 'states' ? 9 : 3;
    assert.equal(await page.locator('iframe').count(), expected);
    for (const frame of page.frames().slice(1)) {
      await frame.locator('[data-variant]').waitFor();
      const metrics = await frame.evaluate(() => ({width:innerWidth,height:innerHeight,overflow:document.documentElement.scrollWidth>innerWidth+1}));
      assert.deepEqual(metrics,{width,height,overflow:false});
      assert.equal(await frame.locator('[data-demo-action]').count(),1);
    }
    results.push({lang,view,width,height,frames:expected});
    if (view==='compare'&&width===320) await page.screenshot({path:`${evidence}/compare-${lang}.png`,fullPage:true});
  }
  await visit({view:'compare',lang:'en',state:'locked',variant:'B'});
  const frame = page.frames()[1];
  await frame.locator('[data-state=locked]').waitFor();
  await frame.getByRole('button',{name:'Simulate unlock'}).click();
  await frame.locator('[data-state=ready]').waitFor();
  await frame.getByRole('button',{name:'Try the interaction'}).click();
  await frame.locator('[data-running=true]').waitFor();
  await frame.getByRole('button',{name:'Finish demo session'}).click();
  await frame.locator('[data-state=completed]').waitFor();
  await frame.getByRole('button',{name:'Try again'}).click();
  await frame.locator('[data-state=ready]').waitFor();
  await page.getByLabel('Height',{exact:true}).fill('700');
  await page.getByLabel('Height',{exact:true}).press('Tab');
  await page.waitForURL('**height=700**');
  assert.equal(await page.locator('iframe').getAttribute('height'),'700');
  await page.reload(); assert.equal(await page.getByLabel('Height',{exact:true}).inputValue(),'700');
  const popupPromise = page.waitForEvent('popup');
  await page.getByRole('link',{name:'Open full size'}).click();
  const popup = await popupPromise; await popup.locator('[data-variant=B]').waitFor();
  assert.equal(await popup.locator('iframe').count(),0);
  assert.equal(await popup.locator('.nativeBar, .controls, header.lab').count(),0);
  await popup.close();
  await visit({view:'unknown',variant:'<script>',state:'invalid',lang:'xx',width:'NaN',height:'99999'});
  assert.equal(await page.locator('iframe').count(),3);
  assert.equal(await page.locator('iframe').first().getAttribute('width'),'360');
  assert.equal(await page.locator('iframe').first().getAttribute('height'),'1200');
  await page.locator('#view').focus(); await page.keyboard.press('Tab');
  assert.equal(await page.locator(':focus').getAttribute('id'),'variant');
  assert.deepEqual(errors,[]); assert.deepEqual(requests,[]);
  await writeFile(`${evidence}/results.json`,JSON.stringify({results,interactions:'passed',urlRestoration:'passed',externalRequests:requests,pageErrors:errors},null,2));
  console.log(`PASS: ${results.length} locale/view/size cases, local state transitions, URL restore, full-size navigation, keyboard focus and input normalization; no external requests.`);
} finally { await browser.close(); }
