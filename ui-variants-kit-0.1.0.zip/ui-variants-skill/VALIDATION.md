# Validation — UI Variants 0.1.0

Checked 2026-10-26. This report distinguishes the skill package, sample renderer, agent behavior, and unavailable evaluations.

| Check | Result | Scope |
| --- | --- | --- |
| Codex skill-creator validator | Passed | Name, standard frontmatter and scaffold checks. |
| Resource links and case JSON | Passed | All relative Markdown links resolve; evaluation cases parse. |
| Local installation | Passed | `~/.codex/skills/ui-variants` points to the package; the user's AGENTS.md includes the visual-choice preference. |
| Standalone gallery | Passed | Chromium: 12 combinations of EN/RU, compare/states/context and 320×480 / 840×360 actual frame sizes. No horizontal overflow inside product frames. |
| Gallery interactions | Passed | Local unlock/start/finish/retry, width/height URL restoration, full-size opening without review chrome, keyboard focus and invalid-parameter normalization. No external requests or page errors. |
| Codex conversation behavior | Passed in this run | Nine independent synthetic cases: choice, combination, rejection, exact reference, typo, no browser, planning-only, backend and question-option limit. Human inspection of actual responses, not a keyword-only grade. |
| Codex artifact creation | Passed in this run | A separate task generated a pottery registration gallery with A/B/C layouts, available/sold-out/closed states, representative listings context and local confirmation. Outer browser review covered 30 frame cases at 320px and 1280px widths, local registration, dismissal and focus return. No external requests or page errors. |
| Codex selected implementation | Passed in this run | Synthetic follow-up produced B with A's heading, three registration states and a decision record. Preview preserved byte-for-byte. Outer browser checks at 320×480 and 1280×800 confirmed the date-first structure, 29px heading, local confirmation/focus return, and absence of gallery controls, overflow and external requests. Unused candidate implementations are absent from selected output. |
| Claude Code | Blocked before evaluation | Installed CLI returned `Your account is on hold and can't use Claude Code`. No behavioral or artifact pass is claimed. |
| Gemini CLI | Not executed | Not installed in this environment; compatibility is based on the published Agent Skills format and documented installation paths. |
| Human effectiveness pilot | Not executed | Requires representative participants/tasks. The worksheet is included; there is no measured reduction percentage. |

## Method and limits

Codex CLI: 0.164.0, configured model reported `gpt-6-astra`; no model override was selected for these runs. Claude Code CLI: 2.1.291. Browser checks used the locally available Playwright/Chromium installation. Narrow viewports are browser emulation, not physical-device or Safari validation; device checks follow the approved task scope rather than establishing a permanent project rule.

The conversation run supplied the skill instructions explicitly and requested independent responses without mutations. The artifact run loaded the installed skill/resources by path and created actual files in an isolated synthetic evaluation directory. These checks establish limited explicit-use behavior, not reliable automatic discovery across all future sessions or versions. The selected implementation follow-up is a guided continuation of that test, not an independent blind trial.

Initial gallery testing caught a one-pixel frame-height discrepancy caused by border-box sizing; the iframe now uses content-box sizing. Review also removed gallery chrome from the template's full-window view and clarified that constraint in the adapter instructions. Relevant renderer checks passed after the change.

The model-generated artifact accurately reported that its own browser check was unavailable; the outer evaluator performed the browser checks afterward. Raw local evidence is retained under ignored `.evidence/` and intentionally excluded from distribution: it contains local paths and runtime logs. Public behavioral prompts and criteria are in `evals/cases.json`.

## Reproduce and extend

Run the skill-creator validator available in your Codex installation against `skills/ui-variants`. For the template browser checks, use an existing Playwright installation:

```sh
PLAYWRIGHT_MODULE=/absolute/path/to/playwright/index.mjs node tests/gallery.mjs
```

This script includes narrow viewport checks; follow your project's device-testing rules before running it. It writes only `.evidence/` artifacts, uses the self-contained local gallery and blocks HTTP(S) requests. If Playwright is installed in this project, `node tests/gallery.mjs` also works.

For behavioral forward testing, provide only the `request` fields from `evals/cases.json` and the skill to the target agent. Keep `criteria` with the reviewer. Record failures and runtime restrictions explicitly. Do not infer Claude/Gemini success from a Codex pass. Follow `references/evaluation.md` inside the skill for the human pilot and integration checks.
