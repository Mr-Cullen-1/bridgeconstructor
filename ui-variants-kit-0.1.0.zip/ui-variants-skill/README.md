# UI Variants

An agent skill for choosing UI through live alternatives, meaningful states and page context. Reviewers choose in chat: “B, with A's heading.” The agent preserves that choice through implementation.

The skill adds **Show all variants** to UI design-choice questions. It does not force a design interview for every CSS fix. Three candidates are a starting point, not a hard requirement. Existing components and Storybook take priority over the included standalone HTML example.

## Install

The portable unit is the complete `skills/ui-variants/` directory. Copy it into one discovery location supported by your client, preserving its references and assets:

| Client | Project | Personal |
| --- | --- | --- |
| Codex | `.agents/skills/ui-variants/` | `~/.agents/skills/ui-variants/` |
| Claude Code | `.claude/skills/ui-variants/` | `~/.claude/skills/ui-variants/` |
| Gemini CLI | `.gemini/skills/ui-variants/` or `.agents/skills/ui-variants/` | `~/.gemini/skills/ui-variants/` or `~/.agents/skills/ui-variants/` |

Some existing Codex installations expose `~/.codex/skills`; use the location your running client actually discovers. Avoid duplicate installations of the same skill. Check the client's skill listing after installation; restart/reload if required. Codex supports symlinked skill directories. Use a directory copy when symlinks are unsuitable, including some Windows setups.

Invoke `$ui-variants` in Codex or `/ui-variants` in Claude Code; Gemini can discover/activate it for a matching request. Core instructions use the shared Agent Skills format; `agents/openai.yaml` is optional Codex-specific UI metadata. A client without native skills can read SKILL.md and its referenced files explicitly, but automatic discovery is then not established.

To make the preference persistent, add this small rule to your own `AGENTS.md`, `CLAUDE.md`, or equivalent configuration after installing the skill:

> When asking me to choose between visual or interactive UI solutions, use ui-variants and include “Show all variants” as an additional answer. Reuse accepted decisions; do not invent a design interview for an exact fix. If I request variants, prepare the comparison within the current execution mode and permissions. Offer this in my language.

Skill descriptions support automatic matching; they are not an execution guarantee. Project permissions, planning mode and device-testing rules still apply.

## Try the example

Open `skills/ui-variants/assets/gallery.html` directly in a browser. It is self-contained, uses synthetic study-session cards and needs no service, account or dependency installation. Compare A/B/C, explore states, or view them in a sample page. Width and height controls resize actual iframes. “Open full size” removes the gallery surroundings. Links preserve settings; selections and feedback remain in chat.

The example is a reusable shell, not a production design kit. Adapt the renderer and scenario data or use your project's real components. File and localhost links only work where the file/server is accessible; team hosting is a separate step.

## Contents and validation

- `skills/ui-variants`: distributable skill, preview template and focused references.
- `evals/cases.json`: independent behavioral cases with reviewer criteria.
- `tests/gallery.mjs`: runnable browser checks; use an existing Playwright installation with `PLAYWRIGHT_MODULE=/absolute/path/to/playwright/index.mjs node tests/gallery.mjs`.
- `VALIDATION.md`: actual checks and known limits for this release.

Research findings, primary sources and their limitations are in `skills/ui-variants/references/research.md`. No measured “90% reduction” is claimed. The human pilot worksheet is provided for measuring decision time and rework; completing it requires real participants and tasks.

Installation references: [Agent Skills](https://agentskills.io/specification), [Codex](https://learn.chatgpt.com/docs/build-skills), [Claude Code](https://code.claude.com/docs/en/skills), [Gemini CLI](https://geminicli.com/docs/cli/skills/). Checked 2026-10-26; actual clients may differ.
